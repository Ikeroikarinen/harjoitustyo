package com.example.harjoitusty;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * RecyclerView Adapter to display Lutemons in a list.
 */
public class LutemonAdapter extends RecyclerView.Adapter<LutemonAdapter.ViewHolder> {

    // Data list
    private List<Lutemon> lutemonList;

    // Optional: click listener for each list item
    private OnLutemonClickListener clickListener;

    /**
     * Constructor with click listener
     * (If you don't need click handling, remove the listener parameter and code referencing it.)
     */
    public LutemonAdapter(List<Lutemon> lutemonList, OnLutemonClickListener listener) {
        this.lutemonList = lutemonList;
        this.clickListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the item layout
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_lutemon, parent, false);
        return new ViewHolder(itemView, clickListener);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Get Lutemon at this position
        Lutemon lutemon = lutemonList.get(position);
        // Bind data to ViewHolder
        holder.bind(lutemon);
    }

    @Override
    public int getItemCount() {
        return lutemonList.size();
    }

    /**
     * Method to update the adapter's data list
     */
    public void updateList(List<Lutemon> newList) {
        lutemonList = newList;
        notifyDataSetChanged();
    }

    /**
     * ViewHolder class for item_lutemon.xml
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView lutemonImageView;
        private TextView nameTextView;
        private TextView typeTextView;
        private TextView statsTextView;

        public ViewHolder(@NonNull View itemView, OnLutemonClickListener listener) {
            super(itemView);

            // Link UI components
            lutemonImageView = itemView.findViewById(R.id.lutemonImageView);
            nameTextView     = itemView.findViewById(R.id.lutemonNameTextView);
            typeTextView     = itemView.findViewById(R.id.lutemonTypeTextView);
            statsTextView    = itemView.findViewById(R.id.lutemonStatsTextView);

            // Optional click handling on entire item
            itemView.setOnClickListener(v -> {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onLutemonClick(position);
                    }
                }
            });
        }

        /**
         * Bind data from Lutemon object to item layout
         */
        public void bind(Lutemon lutemon) {
            // Esimerkkikuva (voisi perustua lutemonin tyyppiin, tms.)
            // lutemonImageView.setImageResource(R.drawable.some_icon);

            nameTextView.setText(lutemon.getName());
            typeTextView.setText("Type: " + lutemon.getType());
            statsTextView.setText(
                    "Attack: " + lutemon.getAttack() +
                            ", Defense: " + lutemon.getDefense() +
                            ", Health: " + lutemon.getCurrentHealth() + "/" + lutemon.getMaxHealth()
            );
        }
    }

    /**
     * Listener interface for item clicks
     */
    public interface OnLutemonClickListener {
        void onLutemonClick(int position);
    }
}
