package com.example.harjoitusty;

import java.util.ArrayList;
import java.util.HashMap;

public class Storage {
    private HashMap<Integer, Lutemon> lutemons;
    private static Storage instance = null;

    private Storage() {
        lutemons = new HashMap<>();
    }

    public static Storage getInstance() {
        if (instance == null) {
            instance = new Storage();
        }
        return instance;
    }

    public void addLutemon(Lutemon lutemon) {
        lutemons.put(lutemon.getId(), lutemon);
    }

    public void removeLutemon(int id) {
        lutemons.remove(id);
    }

    public Lutemon getLutemon(int id) {
        return lutemons.get(id);
    }

    public ArrayList<Lutemon> getAllLutemons() {
        return new ArrayList<>(lutemons.values());
    }
}
