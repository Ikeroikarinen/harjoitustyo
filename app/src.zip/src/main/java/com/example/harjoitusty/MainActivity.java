package com.example.harjoitusty;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView lutemonRecyclerView;
    private LutemonAdapter lutemonAdapter;
    private Button addButton, battleButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lutemonRecyclerView = findViewById(R.id.recyclerView);
        addButton = findViewById(R.id.addButton);
        battleButton = findViewById(R.id.battleButton);

        ArrayList<Lutemon> lutemons = Storage.getInstance().getAllLutemons();
        lutemonRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        lutemonAdapter = new LutemonAdapter(lutemons, position -> {});
        lutemonRecyclerView.setAdapter(lutemonAdapter);

        addButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddLutemonActivity.class);
            startActivity(intent);
        });

        // Tämä avaa BattleActivityn
        battleButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, BattleActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        ArrayList<Lutemon> updatedList = Storage.getInstance().getAllLutemons();
        lutemonAdapter.updateList(updatedList);
    }
}
