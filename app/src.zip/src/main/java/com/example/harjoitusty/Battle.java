package com.example.harjoitusty;

public class Battle {

    /**
     * Simulates a turn-based battle between two Lutemons.
     * @param lutemonA first Lutemon
     * @param lutemonB second Lutemon
     * @param log StringBuilder to collect textual battle log
     * @return the winning Lutemon
     */
    public static Lutemon simulateBattle(Lutemon lutemonA, Lutemon lutemonB, StringBuilder log) {
        Lutemon attacker = lutemonA;
        Lutemon defender = lutemonB;

        // Taistelu jatkuu kunnes jommankumman currentHealth <= 0
        while (attacker.getCurrentHealth() > 0 && defender.getCurrentHealth() > 0) {

            // Kirjataan statsit
            log.append(String.format("%s (HP %d/%d) attacks %s (HP %d/%d)\n",
                    attacker.getName(),
                    attacker.getCurrentHealth(),
                    attacker.getMaxHealth(),
                    defender.getName(),
                    defender.getCurrentHealth(),
                    defender.getMaxHealth()));

            // Hyökkäys
            int damage = attacker.attack();
            defender.defend(damage);

            // Tarkistetaan, selviääkö puolustaja
            if (defender.getCurrentHealth() <= 0) {
                log.append(String.format("%s is killed!\n", defender.getName()));
                attacker.addExperience(1);  // Voittaja saa exp
                return attacker;
            } else {
                log.append(String.format("%s survives with %d HP\n\n",
                        defender.getName(),
                        defender.getCurrentHealth()));
            }

            // Vuoron vaihto
            Lutemon temp = attacker;
            attacker = defender;
            defender = temp;
        }
        // Palautetaan se, joka on yhä hengissä
        return attacker;
    }
}
