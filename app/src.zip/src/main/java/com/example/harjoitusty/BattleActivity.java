package com.example.harjoitusty;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class BattleActivity extends AppCompatActivity {

    private Spinner spinnerA, spinnerB;
    private Button fightButton;
    private TextView battleLogTextView;
    private ArrayList<Lutemon> allLutemons;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_battle);

        spinnerA = findViewById(R.id.spinnerA);
        spinnerB = findViewById(R.id.spinnerB);
        fightButton = findViewById(R.id.fightButton);
        battleLogTextView = findViewById(R.id.battleLogTextView);

        // Haetaan kaikki Lutemonit Storage-luokasta
        allLutemons = Storage.getInstance().getAllLutemons();

        // Asetetaan ne ArrayAdapteriin, jotta ne näkyvät valikoissa
        ArrayAdapter<Lutemon> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                allLutemons
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinnerA.setAdapter(adapter);
        spinnerB.setAdapter(adapter);

        fightButton.setOnClickListener(v -> {
            Lutemon lutemonA = (Lutemon) spinnerA.getSelectedItem();
            Lutemon lutemonB = (Lutemon) spinnerB.getSelectedItem();

            if (lutemonA == lutemonB) {
                battleLogTextView.setText("Select two different Lutemons!");
                return;
            }

            // Alustetaan terveys (jos haluat aina täyden elämän ennen taistelua)
            lutemonA.restoreHealth();
            lutemonB.restoreHealth();

            // Kootaan loki StringBuilderiin
            StringBuilder log = new StringBuilder();
            Lutemon winner = Battle.simulateBattle(lutemonA, lutemonB, log);

            // Poistetaan hävinnyt, jos sen health <= 0
            Lutemon loser = (winner == lutemonA) ? lutemonB : lutemonA;
            if (loser.getCurrentHealth() <= 0) {
                Storage.getInstance().removeLutemon(loser.getId());
            }

            // Näytetään loki + voittaja
            log.append("\nThe battle is over.\nWinner: ").append(winner.getName());
            battleLogTextView.setText(log.toString());

            // Päivitetään spinner-lista, jos häviäjä poistettiin
            adapter.notifyDataSetChanged();
        });
    }
}
