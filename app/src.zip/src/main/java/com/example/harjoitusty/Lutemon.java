package com.example.harjoitusty;

public class Lutemon {
    private int id;
    private String type;      // White, Green, Pink, Orange, Black
    private String name;
    private int attack;
    private int defense;
    private int maxHealth;
    private int currentHealth;
    private int experience;

    public Lutemon(int id, String type, String name, int attack, int defense, int maxHealth) {
        this.id = id;
        this.type = type;
        this.name = name;
        this.attack = attack;
        this.defense = defense;
        this.maxHealth = maxHealth;
        this.currentHealth = maxHealth;
        this.experience = 0;
    }

    // Getters
    public int getId() { return id; }
    public String getType() { return type; }
    public String getName() { return name; }
    public int getAttack() { return attack; }
    public int getDefense() { return defense; }
    public int getMaxHealth() { return maxHealth; }
    public int getCurrentHealth() { return currentHealth; }
    public int getExperience() { return experience; }

    // Setters / logiikkametodit
    public void addExperience(int amount) {
        experience += amount;
    }

    public void restoreHealth() {
        currentHealth = maxHealth;
    }

    public int attack() {
        // esim. attack + pientä satunnaisuutta + experience-lisä
        return (attack + experience) + (int)(Math.random() * 3);
    }

    public void defend(int damage) {
        int netDamage = damage - defense;
        if (netDamage < 0) netDamage = 0;
        currentHealth -= netDamage;
        if (currentHealth < 0) currentHealth = 0;
    }

    // toString(), jotta Lutemon näkyy Spinnerissä nimellä
    @Override
    public String toString() {
        return name + " (" + type + ")";
    }
}
