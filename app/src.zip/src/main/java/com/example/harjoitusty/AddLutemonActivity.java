package com.example.harjoitusty;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class AddLutemonActivity extends AppCompatActivity {

    private Spinner typeSpinner;
    private EditText nameEditText;
    private Button createButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_lutemon);

        // 1. Kytketään layoutin komponentit muuttujiin
        typeSpinner = findViewById(R.id.typeSpinner);
        nameEditText = findViewById(R.id.nameEditText);
        createButton = findViewById(R.id.createButton);

        // 2. Täytetään Spinner, jossa valitaan Lutemonin tyyppi
        //    string-array (lutemon_types) pitää olla määriteltynä strings.xml:ssä
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.lutemon_types,              // esim. ["White", "Green", "Pink", "Orange", "Black"]
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        typeSpinner.setAdapter(adapter);

        // 3. Nappia painamalla luodaan Lutemon
        createButton.setOnClickListener(view -> {
            String name = nameEditText.getText().toString().trim();
            String type = typeSpinner.getSelectedItem().toString();

            if (name.isEmpty()) {
                nameEditText.setError("Please enter a name!");
                return;
            }

            // 4. Luo Lutemon ohjeen mukaisilla statseilla
            //    Käytetään ID:nä esim. System.currentTimeMillis() % 100000
            int id = (int) (System.currentTimeMillis() % 100000);
            Lutemon newLutemon = createLutemon(id, type, name);

            // 5. Tallennetaan Lutemon Storage-luokkaan
            Storage.getInstance().addLutemon(newLutemon);

            // 6. Palataan takaisin MainActivityyn
            finish();
        });
    }

    /**
     * Luo Lutemon ohjeen mukaisin statsein
     * Valkoinen (White): 5 / 4 / 20
     * Vihreä (Green):    6 / 3 / 19
     * Pinkki (Pink):     7 / 2 / 18
     * Oranssi (Orange):  8 / 1 / 17
     * Musta (Black):     9 / 0 / 16
     */
    private Lutemon createLutemon(int id, String type, String name) {
        switch (type) {
            case "Green":
                return new Lutemon(id, "Green", name, 6, 3, 19);
            case "Pink":
                return new Lutemon(id, "Pink", name, 7, 2, 18);
            case "Orange":
                return new Lutemon(id, "Orange", name, 8, 1, 17);
            case "Black":
                return new Lutemon(id, "Black", name, 9, 0, 16);
            default: // White
                return new Lutemon(id, "White", name, 5, 4, 20);
        }
    }
}
